/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

/**
 *
 * @author usuario
 */
public class Ciente extends JFrame {

    private Menu vistaMenu;

    public Ciente() {
        this.setVisible(true); //hacer visible la ventana
        this.setTitle("Ciente");   // Establece el título de la ventana
        this.setSize(700, 500); // Establece el tamaño de la ventana
        this.setLocationRelativeTo(null);  // Centra la ventana en la pantalla
        //this.getContentPane().setBackground(Color.MAGENTA);  // Establece el color de fondoc

        // Crear un JPanel
        JPanel panel = new JPanel();
        Color BackPanel = Color.decode("#F1EEE7");
        panel.setBackground(BackPanel); //Establecemos un color al JPanel
        panel.setLayout(null);// Establece el administrador de diseño del JPanel (null)

        //primer JLabel
        JLabel label1 = new JLabel();
        label1.setText("Cliente"); //añadirle texto
        label1.setBounds(245, 40, 190, 40); // Agrega un JLabel y ubícalo en el punto (240(x), 10(y)) con un tamaño de 200x30
        Color color = Color.decode("#005832");
        label1.setForeground(color); //cambiar el color a la letra
        label1.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 25)); //cambiar tamaño de letra
        label1.setOpaque(true); //para especificar si el componente debería ser dibujado de manera opaca(true) o transparente(false).
        Color labelBack1 = Color.decode("#F1EEE7");
        label1.setBackground(labelBack1);  //agregarle un fondo al JLabel
        label1.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        label1.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(label1); // Agrega el JLabel al JPanel

        JLabel Username = new JLabel();
        Username.setText("Username: ");
        Username.setBounds(110, 130, 215, 40);
        Color colorUbi = Color.decode("#F2B90F");
        Username.setForeground(colorUbi);
        Username.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 18));
        Username.setOpaque(true);
        Color BackUbi = Color.decode("#DFF2EB");
        Username.setBackground(BackUbi);
        Username.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        Username.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(Username); // Agrega el JLabel al JPanel
        JTextField ubicacion = new JTextField(25);//creamos el texfiel
        ubicacion.setBounds(330, 130, 215, 30);
        ubicacion.setHorizontalAlignment(JTextField.CENTER);
        panel.add(ubicacion);

        JLabel Horario = new JLabel();
        Horario.setText("Password: ");
        Horario.setBounds(110, 200, 215, 40);
        Color colorHorario = Color.decode("#F2B90F");
        Horario.setForeground(colorHorario);
        Horario.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 18));
        Horario.setOpaque(true);
        Color Backhorario = Color.decode("#DFF2EB");
        Horario.setBackground(Backhorario);
        Horario.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        Horario.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(Horario); // Agrega el JLabel al JPanel
        JTextField horario = new JTextField(25);//creamos el texfiel
        horario.setBounds(330, 200, 215, 30);
        horario.setHorizontalAlignment(JTextField.CENTER);
        panel.add(horario);

        JButton confirmButton = new JButton("Registrar"); // Agregamos un botón de confirmación
        confirmButton.setBounds(380, 270, 100, 30);
        panel.add(confirmButton);

        confirmButton.addActionListener((ActionEvent e) -> {
            String username = ubicacion.getText();
            String password = horario.getText();

            if (!username.isEmpty() && !password.isEmpty()) {

                setVisible(false);
                if (vistaMenu == null) {
                    vistaMenu = new Menu();
                }
                vistaMenu.setVisible(true);

            } else {
                JOptionPane.showMessageDialog(this, "Ingrese los campos requeridos");
            }

        });

        panel.add(confirmButton);

        this.getContentPane().add(panel);

        // Establece la operación de cierre
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }

}
