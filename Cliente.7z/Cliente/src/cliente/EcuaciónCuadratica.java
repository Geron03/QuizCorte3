/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

/**
 *
 * @author usuario
 */
public class EcuaciónCuadratica extends JFrame {

    private Menu menu;

    public EcuaciónCuadratica() {
        this.setVisible(true); //hacer visible la ventana
        this.setTitle("Divisores");   // Establece el título de la ventana
        this.setSize(700, 500); // Establece el tamaño de la ventana
        this.setLocationRelativeTo(null);  // Centra la ventana en la pantalla
        //this.getContentPane().setBackground(Color.MAGENTA);  // Establece el color de fondoc

        // Crear un JPanel
        JPanel panel = new JPanel();
        Color BackPanel = Color.decode("#F1EEE7");
        panel.setBackground(BackPanel); //Establecemos un color al JPanel
        panel.setLayout(null);// Establece el administrador de diseño del JPanel (null)

        //primer JLabel
        JLabel label1 = new JLabel();
        label1.setText("Ecuación Cuadratica"); //añadirle texto
        label1.setBounds(190, 50, 340, 40); // Agrega un JLabel y ubícalo en el punto (240(x), 10(y)) con un tamaño de 200x30
        Color color = Color.decode("#005832");
        label1.setForeground(color); //cambiar el color a la letra
        label1.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 25)); //cambiar tamaño de letra
        label1.setOpaque(true); //para especificar si el componente debería ser dibujado de manera opaca(true) o transparente(false).
        Color labelBack1 = Color.decode("#F1EEE7");
        label1.setBackground(labelBack1);  //agregarle un fondo al JLabel
        label1.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        label1.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(label1); // Agrega el JLabel al JPanel

        JLabel TextA = new JLabel();
        TextA.setText("a: ");
        TextA.setBounds(110, 130, 215, 40);
        Color colorTextA = Color.decode("#F2B90F");
        TextA.setForeground(colorTextA);
        TextA.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 18));
        TextA.setOpaque(true);
        Color BackColorTextA = Color.decode("#DFF2EB");
        TextA.setBackground(BackColorTextA);
        TextA.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        TextA.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(TextA); // Agrega el JLabel al JPanel
        JTextField textA = new JTextField(25);//creamos el texfiel
        textA.setBounds(330, 135, 215, 30);
        textA.setHorizontalAlignment(JTextField.CENTER);
        panel.add(textA);

        JLabel TextB = new JLabel();
        TextB.setText("b: ");
        TextB.setBounds(110, 180, 215, 40);
        Color colorUbi = Color.decode("#F2B90F");
        TextB.setForeground(colorUbi);
        TextB.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 18));
        TextB.setOpaque(true);
        Color BackUbi = Color.decode("#DFF2EB");
        TextB.setBackground(BackUbi);
        TextB.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        TextB.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(TextB); // Agrega el JLabel al JPanel
        JTextField textB = new JTextField(25);//creamos el texfiel
        textB.setBounds(330, 185, 215, 30);
        textB.setHorizontalAlignment(JTextField.CENTER);
        panel.add(textB);

        JLabel TextC = new JLabel();
        TextC.setText("c: ");
        TextC.setBounds(110, 230, 215, 40);
        Color colorTextC = Color.decode("#F2B90F");
        TextC.setForeground(colorTextC);
        TextC.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 18));
        TextC.setOpaque(true);
        Color BackTextC = Color.decode("#DFF2EB");
        TextC.setBackground(BackTextC);
        TextC.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        TextC.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(TextC); // Agrega el JLabel al JPanel
        JTextField textC = new JTextField(25);//creamos el texfiel
        textC.setBounds(330, 235, 215, 30);
        textC.setHorizontalAlignment(JTextField.CENTER);
        panel.add(textC);

        JButton confirmButton = new JButton("Enviar"); // Agregamos un botón de confirmación
        confirmButton.setBounds(385, 280, 100, 30);
        panel.add(confirmButton);

        JButton confirmButton2 = new JButton("Regresar"); // Agregamos un botón de confirmación
        confirmButton2.setBounds(380, 400, 100, 30);
        panel.add(confirmButton2);

        confirmButton2.addActionListener((ActionEvent f) -> {
            // Inicializa WindowLocal1 si aún no se ha hecho
            setVisible(false);
            if (menu == null) {
                menu = new Menu();
            }
            menu.setVisible(true);

        });

        this.getContentPane().add(panel);

        // Establece la operación de cierre
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }

}
