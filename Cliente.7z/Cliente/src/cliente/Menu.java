/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 *
 * @author usuario
 */
public class Menu extends JFrame {

    private Divisores VistaDivisores;
    private EcuaciónCuadratica VistaCuadratica;
    

    public Menu() {
        this.setVisible(true); //hacer visible la ventana
        this.setTitle("Menu");   // Establece el título de la ventana
        this.setSize(700, 500); // Establece el tamaño de la ventana
        this.setLocationRelativeTo(null);  // Centra la ventana en la pantalla
        //this.getContentPane().setBackground(Color.MAGENTA);  // Establece el color de fondoc

        // Crear un JPanel
        JPanel panel = new JPanel();
        Color BackPanel = Color.decode("#F1EEE7");
        panel.setBackground(BackPanel); //Establecemos un color al JPanel
        panel.setLayout(null);// Establece el administrador de diseño del JPanel (null)

        //primer JLabel
        JLabel label1 = new JLabel();
        label1.setText("MENU"); //añadirle texto
        label1.setBounds(245, 50, 190, 40); // Agrega un JLabel y ubícalo en el punto (240(x), 10(y)) con un tamaño de 200x30
        Color color = Color.decode("#005832");
        label1.setForeground(color); //cambiar el color a la letra
        label1.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 25)); //cambiar tamaño de letra
        label1.setOpaque(true); //para especificar si el componente debería ser dibujado de manera opaca(true) o transparente(false).
        Color labelBack1 = Color.decode("#F1EEE7");
        label1.setBackground(labelBack1);  //agregarle un fondo al JLabel
        label1.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        label1.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL
        panel.add(label1); // Agrega el JLabel al JPanel

        JButton ContDivisores = new JButton();
        ContDivisores.setText("Contar Divisores"); //añadirle texto
        ContDivisores.setBounds(60, 200, 250, 40); // Agrega un JLabel y ubícalo en el punto (240(x), 10(y)) con un tamaño de 200x30
        Color colorDivisores = Color.decode("#005832");
        ContDivisores.setForeground(colorDivisores); //cambiar el color a la letra
        ContDivisores.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 15)); //cambiar tamaño de letra
        ContDivisores.setOpaque(true); //para especificar si el componente debería ser dibujado de manera opaca(true) o transparente(false).
        Color CBackDivisores = Color.decode("#F1EEE7");
        ContDivisores.setBackground(CBackDivisores);  //agregarle un fondo al JLabel
        ContDivisores.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        ContDivisores.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL

        ContDivisores.addActionListener((ActionEvent v) -> {
            // Inicializa WindowLocal1 si aún no se ha hecho
            setVisible(false);
            if (VistaDivisores == null) {
                VistaDivisores = new Divisores();
            }
            VistaDivisores.setVisible(true);

        });
        panel.add(ContDivisores); // Agrega el JLabel al JPanel

        JButton EcuaciónCuadric = new JButton();
        EcuaciónCuadric.setText("Ecuación Cuadratica"); //añadirle texto
        EcuaciónCuadric.setBounds(350, 200, 250, 40); // Agrega un JLabel y ubícalo en el punto (240(x), 10(y)) con un tamaño de 200x30
        Color colorEcuación = Color.decode("#005832");
        EcuaciónCuadric.setForeground(colorEcuación); //cambiar el color a la letra
        EcuaciónCuadric.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 15)); //cambiar tamaño de letra
        EcuaciónCuadric.setOpaque(true); //para especificar si el componente debería ser dibujado de manera opaca(true) o transparente(false).
        Color CBackEcuación = Color.decode("#F1EEE7");
        EcuaciónCuadric.setBackground(CBackEcuación);  //agregarle un fondo al JLabel
        EcuaciónCuadric.setHorizontalAlignment(JLabel.CENTER);//CENTRAR TEXTO DE MANERA HORIZONTAL
        EcuaciónCuadric.setVerticalAlignment(JLabel.CENTER);//CENTRAR EL TEXTO DE MANERA VERTICAL

        EcuaciónCuadric.addActionListener((ActionEvent M) -> {
            // Inicializa WindowLocal1 si aún no se ha hecho
            setVisible(false);
            if (VistaCuadratica == null) {
                VistaCuadratica = new EcuaciónCuadratica();
            }
            VistaCuadratica.setVisible(true);

        });

        panel.add(EcuaciónCuadric); // Agrega el JLabel al JPanel

        JButton confirmButton2 = new JButton("Regresar"); // Agregamos un botón de confirmación
        confirmButton2.setBounds(380, 400, 100, 30);
        panel.add(confirmButton2);

        this.getContentPane().add(panel);

        // Establece la operación de cierre
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }

}
